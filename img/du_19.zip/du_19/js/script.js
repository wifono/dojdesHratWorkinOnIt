(function($) {

	var menu = $('.controls'),
		menuLinks = menu.find('a'),
		gallery = $('.gallery'),
		galleries = $('.gallery-set');

	
	// skryjeme vsetky gallery-sety okrem prveho
	galleries.not(':first').hide();


	// pridame loading ikonku do galerie
	var loading = $('<div class="container loading"><img src="img/loading.svg"></div>');
	loading.appendTo(gallery);


	// po kliknuti na link v menu chceme nacitat prvu sekciu
	menuLinks.on('click', function(event) {

		// aby sme neodskocili na adresu linku
		event.preventDefault();

		
		var a = $(this), // link na ktory sme klikli
			li = a.parent(); // jeho rodic, budeme ho nastavovat ako "selected"


		// koncime, ak uz li je oznaceny, cize ak sa snazime nacitat stranku, ktora je prave zobrazena
		// ALEBO ak je loading viditelny, cize nejaka nacitavanie prave prebieha
		// lebo inac keby 20x rychlo kliknem, tak spustim 20 ajax requestov a to nechcem.. chcel len 1
		// cize vzdy ked vidim loading ikonku, nechcem pokracovat dalej vo funkcii, lebo uz jeden ajax bezi
		if ( li.is('.selected') || loading.is(':visible') ) {
			return;
		}


		// sem sa dostaneme iba ak sa snazime zobrazit inu podstranku
		var href = a.attr('href'), // url adresa, z ktore budeme nacitavat novy obsah
			currentGallery = gallery.find('.gallery-set'); // gallery set, ktory je prave zobrazeny


		// nechame zmiznut aktualny gallery set a zobrazime loading ikonku
		currentGallery.hide();
		loading.fadeIn();
		

		// oznacime aktualne kliknute li v menu ako selected
		// a vsetky ostatne li oznacime ako ne-selected.. cize im vezmeme selected
		li.addClass('selected')
		  .siblings('li').removeClass('selected');



		// potrebujme od prehlaidaca, aby sa pozrel na dalsiu stranku
		// a teda spravime AJAX request
		var request = $.ajax({
			url: href
		});


		// .done funkcia sa zavola, iba ak sme uspesne ziskali data z novej stranky 
		// v data bude ulozeny kompletny html kod stranky z adresy, na ktoru sme klikli
		request.done(function(data) {

			// v html kode, ktory sme ziskali, najdeme nove obrazky
			var newPics = $(data).find('.gallery-set a');

			// najdeme aktualny gallery set a jeho vnutro nahradime novymi obrazkami
			currentGallery.html( newPics );

			// nechame zobrazit nove obrazky
			currentGallery.delay(750).fadeIn();

			// dolezita vec ohladom funkcie delay, pozri nizsie 

		});


		// .fail funkcia bude zavolana, iba ak bol request neuspesny, nepodarilo sa nam ziskat data, 
		request.fail(function() {

			// toto by malo byt riesene inak, alert okna su otravne
			// ale pre ucebne ucely postaci
			alert('nepodarilo sa:(');

		});


		// .always sa spusti bez ohladu na to, ci sme mali uspech alebo nie
		request.always(function() {
			
			// a to je dobre miesto, kde nechat zmiznut loading ikonku
			// loading ikonku chceme zmiznut bez ohladu na to, ci sa podarilo nacitat obsah alebo nie
			loading.delay(200).fadeOut();

		});


		/**
		 * 
		 * IMPORTANT: tie .delay() funkcii by v skutocnom kode skutocnej stranky neboli!!
		 * delay pouzivam len preto, aby som nasimuloval cakanie.. ze sa obsah zobrazi az po 0.75 sekundy
		 * 
		 * totiz nasu stranku spustame z localhostu a teda vsetky obrazky sa nacitaju extremne rychlo
		 * keby bola ale stranka na serveri, na internete, chvilu by to trvalo.. a vyzeralo by to podobne, ako nas delay
		 * pri uploade na skutocnu stranku by sme ten delay ODSTRANILI
		 * 
		 */

	});
	

})(jQuery);